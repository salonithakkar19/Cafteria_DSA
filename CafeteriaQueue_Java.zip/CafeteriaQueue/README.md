# Cafeteria Order Management System (Queue - FIFO) - Java Swing

Group 5 | AI & Data Science | Data Structures (ADCOR2PC202)
Vidhi Patil (43), Saloni Thakkar (60), Kartik Vegad (63)

## Run
- Double-click `CafeteriaOrderSystem.jar`  (needs Java 8+), or
- Windows: double-click `run.bat`   | Linux/macOS: `./run.sh`
- Console tests (T1-T7): `java -cp out QueueTest`  (after compiling)

## Data structure
`OrderQueue.java` = circular-array queue written from scratch (front, rear, count).
No ArrayList / LinkedList / java.util.Queue is used.
Enqueue, Dequeue, Peek, isFull, isEmpty = O(1); Display = O(n).
Change capacity with `MAX` in `CafeteriaGUI.java` (default 5, as in the report).

## Files
src/Order.java, src/OrderQueue.java, src/CafeteriaGUI.java, src/QueueTest.java
