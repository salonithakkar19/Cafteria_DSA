/**
 * Circular-array Queue (FIFO) for cafeteria orders.
 * Implemented from scratch - no java.util collections are used.
 *
 *  front : index of the oldest order (next to be served)
 *  rear  : index of the newest order
 *  count : number of pending orders (removes front==rear ambiguity)
 *
 *  enqueue / dequeue / peek / isFull / isEmpty  -> O(1)
 *  display                                      -> O(n)
 */
public class OrderQueue {
    private final Order[] orders;
    private final int max;
    private int front;
    private int rear;
    private int count;

    public OrderQueue(int max) {
        this.max = max;
        this.orders = new Order[max];
        this.front = 0;
        this.rear = -1;
        this.count = 0;
    }

    public boolean isEmpty() { return count == 0; }
    public boolean isFull()  { return count == max; }

    /** Enqueue: add at rear. Returns false on Queue Overflow. */
    public boolean enqueue(Order o) {
        if (isFull()) return false;               // Queue Overflow
        rear = (rear + 1) % max;
        orders[rear] = o;
        count++;
        return true;
    }

    /** Dequeue: remove from front. Returns null on Queue Underflow. */
    public Order dequeue() {
        if (isEmpty()) return null;               // Queue Underflow
        Order served = orders[front];
        orders[front] = null;                     // free the slot
        front = (front + 1) % max;
        count--;
        return served;
    }

    /** Look at the next order to be served without removing it. */
    public Order peek() {
        return isEmpty() ? null : orders[front];
    }

    /** Display: pending orders from front to rear as text. */
    public String display() {
        if (isEmpty()) return "No pending orders";
        StringBuilder sb = new StringBuilder();
        int idx = front;
        for (int i = 0; i < count; i++) {
            sb.append(i + 1).append(". ").append(orders[idx]).append("\n");
            idx = (idx + 1) % max;
        }
        return sb.toString();
    }

    // ---- read-only accessors used by the GUI to draw the array ----
    public int capacity()        { return max; }
    public int size()            { return count; }
    public int getFront()        { return front; }
    public int getRear()         { return rear; }
    public Order getSlot(int i)  { return orders[i]; }
}
