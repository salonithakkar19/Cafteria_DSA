import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.*;

/** Swing GUI for the Cafeteria Order Management System (Queue / FIFO). */
public class CafeteriaGUI extends JFrame {

    private static final int MAX = 5;   // queue capacity - change here (report uses 5)
    private static final String[] MENU = {
        "Sandwich", "Pizza", "Burger", "Pasta", "Samosa", "Vada Pav",
        "Dosa", "French Fries", "Coffee", "Tea", "Cold Drink"
    };

    private static final Color BG      = new Color(0xF4F6FA);
    private static final Color PRIMARY = new Color(0x2F5DA8);
    private static final Color GREEN   = new Color(0x2E8B57);
    private static final Color ORANGE  = new Color(0xE67E22);
    private static final Color RED     = new Color(0xC0392B);

    private final OrderQueue queue = new OrderQueue(MAX);
    private int nextOrderNo = 1;

    private final JTextField nameField = new JTextField();
    private final JComboBox<String> itemBox = new JComboBox<>(MENU);
    private final JTextArea pendingArea = new JTextArea();
    private final JTextArea logArea = new JTextArea();
    private final JLabel statusLabel = new JLabel(" ");
    private final JLabel sizeLabel = new JLabel();
    private final JLabel nowServing = new JLabel("Now Serving: -", SwingConstants.CENTER);
    private final JLabel nextUp = new JLabel("Next in line: -", SwingConstants.CENTER);
    private final ArrayPanel arrayPanel = new ArrayPanel();

    public CafeteriaGUI() {
        super("Cafeteria Order Management System  |  Queue (FIFO)");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setBackground(BG);
        setLayout(new BorderLayout(10, 10));

        add(buildHeader(), BorderLayout.NORTH);
        add(buildLeft(), BorderLayout.WEST);
        add(buildCenter(), BorderLayout.CENTER);
        add(buildFooter(), BorderLayout.SOUTH);
        ((JComponent) getContentPane()).setBorder(new EmptyBorder(0, 10, 10, 10));

        itemBox.setEditable(true);
        refresh();
        setSize(1000, 680);
        setMinimumSize(new Dimension(900, 600));
        setLocationRelativeTo(null);
    }

    // ---------------- UI construction ----------------
    private JComponent buildHeader() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(PRIMARY);
        p.setBorder(new EmptyBorder(14, 18, 14, 18));
        JLabel t = new JLabel("\uD83C\uDF7D  Cafeteria Order Management System");
        t.setForeground(Color.WHITE);
        t.setFont(new Font("SansSerif", Font.BOLD, 24));
        JLabel s = new JLabel("First In First Out - orders are served in the order they are received");
        s.setForeground(new Color(0xDCE6F7));
        s.setFont(new Font("SansSerif", Font.PLAIN, 13));
        p.add(t, BorderLayout.NORTH);
        p.add(s, BorderLayout.SOUTH);
        return p;
    }

    private JComponent buildLeft() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(BG);
        p.setPreferredSize(new Dimension(270, 0));

        JPanel form = card("New Order");
        form.setLayout(new GridLayout(0, 1, 0, 6));
        form.add(new JLabel("Customer name (optional)"));
        form.add(nameField);
        form.add(new JLabel("Food item (choose or type)"));
        form.add(itemBox);
        JButton add = button("\u2795  Add Order (Enqueue)", GREEN);
        add.addActionListener(e -> addOrder());
        form.add(add);
        nameField.addActionListener(e -> addOrder());

        JPanel serve = card("Serve");
        serve.setLayout(new GridLayout(0, 1, 0, 6));
        JButton srv = button("\u2705  Serve Next (Dequeue)", ORANGE);
        srv.addActionListener(e -> serveOrder());
        JButton clr = button("Clear Log", Color.GRAY);
        clr.addActionListener(e -> logArea.setText(""));
        serve.add(srv);
        serve.add(nowServing);
        serve.add(nextUp);
        serve.add(clr);
        nowServing.setFont(new Font("SansSerif", Font.BOLD, 13));
        nextUp.setFont(new Font("SansSerif", Font.PLAIN, 12));

        p.add(form);
        p.add(Box.createVerticalStrut(10));
        p.add(serve);
        p.add(Box.createVerticalGlue());
        return p;
    }

    private JComponent buildCenter() {
        JPanel p = new JPanel(new BorderLayout(0, 10));
        p.setBackground(BG);

        JPanel arr = card("Queue Array (circular)  -  live view");
        arr.setLayout(new BorderLayout());
        arrayPanel.setPreferredSize(new Dimension(0, 190));
        arr.add(arrayPanel, BorderLayout.CENTER);

        pendingArea.setEditable(false);
        pendingArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        JScrollPane ps = new JScrollPane(pendingArea);
        ps.setBorder(titled("Pending Orders (front \u2192 rear)"));

        logArea.setEditable(false);
        logArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane ls = new JScrollPane(logArea);
        ls.setBorder(titled("Activity Log"));

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, ps, ls);
        split.setResizeWeight(0.5);
        split.setBorder(null);

        p.add(arr, BorderLayout.NORTH);
        p.add(split, BorderLayout.CENTER);
        return p;
    }

    private JComponent buildFooter() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(Color.WHITE);
        p.setBorder(new EmptyBorder(8, 12, 8, 12));
        statusLabel.setFont(new Font("SansSerif", Font.BOLD, 13));
        sizeLabel.setFont(new Font("SansSerif", Font.PLAIN, 13));
        p.add(statusLabel, BorderLayout.WEST);
        p.add(sizeLabel, BorderLayout.EAST);
        return p;
    }

    // ---------------- actions ----------------
    private void addOrder() {
        String item = String.valueOf(itemBox.getEditor().getItem()).trim();
        String name = nameField.getText().trim();
        if (item.isEmpty()) {
            status("Please choose or type a food item.", RED);
            return;
        }
        if (name.isEmpty()) name = "Guest";

        Order o = new Order(nextOrderNo, name, item);
        if (queue.enqueue(o)) {
            nextOrderNo++;
            log("ENQUEUE  -> " + o);
            status("Order added: " + o, GREEN);
            nameField.setText("");
        } else {
            log("OVERFLOW -> cannot add \"" + item + "\" (queue full)");
            status("Queue Overflow: the queue is full. Serve an order first.", RED);
            JOptionPane.showMessageDialog(this,
                "Queue Overflow!\nThe queue is full (" + MAX + " orders).\nServe an order before adding a new one.",
                "Queue Full", JOptionPane.WARNING_MESSAGE);
        }
        refresh();
    }

    private void serveOrder() {
        Order o = queue.dequeue();
        if (o == null) {
            log("UNDERFLOW -> no orders to serve");
            status("Queue Underflow: there are no orders to serve.", RED);
            JOptionPane.showMessageDialog(this,
                "Queue Underflow!\nThere are no pending orders to serve.",
                "Queue Empty", JOptionPane.INFORMATION_MESSAGE);
        } else {
            log("DEQUEUE  -> served " + o);
            status("Order served: " + o, GREEN);
            nowServing.setText("Now Serving: #" + o.getOrderNo() + " " + o.getItem());
        }
        refresh();
    }

    // ---------------- helpers ----------------
    private void refresh() {
        pendingArea.setText(queue.display());
        Order nxt = queue.peek();
        nextUp.setText(nxt == null ? "Next in line: -" : "Next in line: #" + nxt.getOrderNo() + " " + nxt.getItem());
        sizeLabel.setText("Pending: " + queue.size() + " / " + queue.capacity()
            + (queue.isFull() ? "   [FULL]" : queue.isEmpty() ? "   [EMPTY]" : ""));
        arrayPanel.repaint();
    }

    private void status(String msg, Color c) {
        statusLabel.setForeground(c);
        statusLabel.setText(msg);
    }

    private void log(String s) {
        logArea.append(s + "\n");
        logArea.setCaretPosition(logArea.getDocument().getLength());
    }

    private static JPanel card(String title) {
        JPanel p = new JPanel();
        p.setBackground(Color.WHITE);
        p.setBorder(titled(title));
        p.setAlignmentX(Component.LEFT_ALIGNMENT);
        return p;
    }

    private static TitledBorder titled(String t) {
        TitledBorder b = BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(0xCBD3E1)), " " + t + " ");
        b.setTitleFont(new Font("SansSerif", Font.BOLD, 13));
        b.setTitleColor(PRIMARY);
        return b;
    }

    private static JButton button(String text, Color c) {
        JButton b = new JButton(text);
        b.setBackground(c);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("SansSerif", Font.BOLD, 14));
        b.setFocusPainted(false);
        b.setOpaque(true);
        b.setBorderPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setPreferredSize(new Dimension(220, 38));
        return b;
    }

    /** Draws the underlying circular array with FRONT and REAR pointers. */
    private class ArrayPanel extends JPanel {
        ArrayPanel() { setBackground(Color.WHITE); }

        @Override
        protected void paintComponent(Graphics g0) {
            super.paintComponent(g0);
            Graphics2D g = (Graphics2D) g0;
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

            int cap = queue.capacity();
            int gap = 10, margin = 10;
            int boxW = Math.min(120, (getWidth() - 2 * margin - gap * (cap - 1)) / cap);
            int boxH = 70;
            int total = cap * boxW + gap * (cap - 1);
            int x0 = (getWidth() - total) / 2;
            int y = 15;

            for (int i = 0; i < cap; i++) {
                int x = x0 + i * (boxW + gap);
                Order o = queue.getSlot(i);
                boolean isFront = !queue.isEmpty() && i == queue.getFront();
                boolean isRear  = !queue.isEmpty() && i == queue.getRear();

                g.setColor(o == null ? new Color(0xEEF1F6) : new Color(0xDFF3E6));
                g.fillRoundRect(x, y, boxW, boxH, 14, 14);
                g.setStroke(new BasicStroke(isFront ? 3f : 1.5f));
                g.setColor(isFront ? PRIMARY : new Color(0xAAB4C5));
                g.drawRoundRect(x, y, boxW, boxH, 14, 14);

                g.setColor(Color.DARK_GRAY);
                if (o == null) {
                    g.setFont(new Font("SansSerif", Font.ITALIC, 12));
                    center(g, "empty", x, y + boxH / 2 + 4, boxW);
                } else {
                    g.setFont(new Font("SansSerif", Font.BOLD, 15));
                    center(g, "#" + o.getOrderNo(), x, y + 28, boxW);
                    g.setFont(new Font("SansSerif", Font.PLAIN, 12));
                    center(g, shorten(o.getItem(), 14), x, y + 48, boxW);
                }
                g.setFont(new Font("Monospaced", Font.PLAIN, 12));
                g.setColor(Color.GRAY);
                center(g, "[" + i + "]", x, y + boxH + 16, boxW);

                int py = y + boxH + 36;
                g.setFont(new Font("SansSerif", Font.BOLD, 12));
                if (isFront) { g.setColor(PRIMARY); center(g, "\u25B2 FRONT", x, py, boxW); py += 16; }
                if (isRear)  { g.setColor(RED);     center(g, "\u25B2 REAR",  x, py, boxW); }
            }
        }

        private void center(Graphics2D g, String s, int x, int baseY, int w) {
            int sw = g.getFontMetrics().stringWidth(s);
            g.drawString(s, x + (w - sw) / 2, baseY);
        }

        private String shorten(String s, int n) {
            return s.length() <= n ? s : s.substring(0, n - 1) + "\u2026";
        }
    }

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); } catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new CafeteriaGUI().setVisible(true));
    }
}
