/** A single cafeteria order (the element stored inside the queue). */
public class Order {
    private final int orderNo;
    private final String customer;
    private final String item;

    public Order(int orderNo, String customer, String item) {
        this.orderNo = orderNo;
        this.customer = customer;
        this.item = item;
    }

    public int getOrderNo()    { return orderNo; }
    public String getCustomer(){ return customer; }
    public String getItem()    { return item; }

    @Override
    public String toString() {
        return "#" + orderNo + "  " + item + "  (" + customer + ")";
    }
}
