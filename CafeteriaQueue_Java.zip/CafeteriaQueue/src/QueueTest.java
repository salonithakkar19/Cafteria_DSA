/** Console test cases T1-T7 from the Stage 2 report (run: java QueueTest). */
public class QueueTest {
    static int pass = 0, fail = 0;
    static void check(String id, boolean ok) {
        System.out.println((ok ? "PASS  " : "FAIL  ") + id);
        if (ok) pass++; else fail++;
    }
    static Order o(String s) { return new Order(1, "Guest", s); }

    public static void main(String[] a) {
        OrderQueue q = new OrderQueue(5);
        q.enqueue(o("Sandwich"));
        check("T1 enqueue + display", q.display().contains("Sandwich"));

        q = new OrderQueue(5);
        q.enqueue(o("Sandwich")); q.enqueue(o("Pizza")); q.enqueue(o("Burger"));
        Order s = q.dequeue();
        check("T2 FIFO order", s.getItem().equals("Sandwich") && q.peek().getItem().equals("Pizza"));

        q = new OrderQueue(5);
        check("T3 underflow", q.dequeue() == null);
        check("T4 display empty", q.display().equals("No pending orders"));

        q = new OrderQueue(5);
        boolean allOk = true;
        for (char c = 'A'; c <= 'E'; c++) allOk &= q.enqueue(o("" + c));
        check("T5 overflow", allOk && !q.enqueue(o("F")) && q.size() == 5);

        q = new OrderQueue(5);
        for (char c = 'A'; c <= 'E'; c++) q.enqueue(o("" + c));
        q.dequeue(); q.dequeue();
        check("T6 circular reuse", q.enqueue(o("F")) && q.enqueue(o("G"))
              && q.peek().getItem().equals("C") && q.size() == 5);

        q = new OrderQueue(5);
        q.enqueue(o("A"));
        check("T7 serve until empty", q.dequeue() != null && q.dequeue() == null
              && q.display().equals("No pending orders"));

        System.out.println("\n" + pass + " passed, " + fail + " failed");
    }
}
